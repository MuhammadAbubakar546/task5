
function table(){
    let num=parseInt( document.getElementById("n").value);
    
for(let i=1;i<=10;i++){

    
document.write(num+ "  ✕  "+i+ "  = " +i*num +"<br>")


}
}
document.getElementById("t").addEventListener("click",table)